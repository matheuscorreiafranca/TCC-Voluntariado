const BASE_URL = '/api/v1';

interface ApiError {
  message: string;
  status: number;
}

export class ApiException extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.name = 'ApiException';
    this.status = status;
  }
}

function getAuthHeaders(): Record<string, string> {
  const token = localStorage.getItem('voluntamais_token');
  if (token) {
    return { Authorization: `Bearer ${token}` };
  }
  return {};
}

export async function apiGet<T>(path: string): Promise<T> {
  const response = await fetch(`${BASE_URL}${path}`, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
      ...getAuthHeaders(),
    },
  });

  if (!response.ok) {
    const body = await response.json().catch(() => ({ message: 'Erro desconhecido' }));
    throw new ApiException(body.message || `Erro ${response.status}`, response.status);
  }

  return response.json();
}

export async function apiPost<T>(path: string, data?: unknown): Promise<T> {
  const response = await fetch(`${BASE_URL}${path}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      ...getAuthHeaders(),
    },
    body: data ? JSON.stringify(data) : undefined,
  });

  if (!response.ok) {
    const body = await response.json().catch(() => ({ message: 'Erro desconhecido' }));
    throw new ApiException(body.message || `Erro ${response.status}`, response.status);
  }

  return response.json();
}

export async function apiPatch<T>(path: string, data?: unknown): Promise<T> {
  const response = await fetch(`${BASE_URL}${path}`, {
    method: 'PATCH',
    headers: {
      'Content-Type': 'application/json',
      ...getAuthHeaders(),
    },
    body: data ? JSON.stringify(data) : undefined,
  });

  if (!response.ok) {
    const body = await response.json().catch(() => ({ message: 'Erro desconhecido' }));
    throw new ApiException(body.message || `Erro ${response.status}`, response.status);
  }

  return response.json();
}
