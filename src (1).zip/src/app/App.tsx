import { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { HomePage } from './pages/HomePage';
import { OportunidadesPage } from './pages/OportunidadesPage';
import { PainelPage } from './pages/PainelPage';
import { PainelOrgPage } from './pages/PainelOrgPage';
import { DetalhesPage } from './pages/DetalhesPage';

import { LoginModal } from './components/modals/LoginModal';
import { CadastroModal } from './components/modals/CadastroModal';
import { NovoProjetoModal } from './components/modals/NovoProjetoModal';
import { CertificadosModal } from './components/modals/CertificadosModal';
import { CalendarioModal } from './components/modals/CalendarioModal';
import { AccessibilityWidget } from './components/ui/AccessibilityWidget';

import { AuthProvider, useAuth } from './contexts/AuthContext';
import { cadastrarVoluntario } from './services/voluntarioService';
import { ApiException } from './services/apiClient';
import { opportunities } from './data/mocks';

function AppContent() {
  const auth = useAuth();

  const [menuOpen, setMenuOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState('Todas');
  const [showCadastro, setShowCadastro] = useState(false);
  const [showLogin, setShowLogin] = useState(false);
  const [showCertificados, setShowCertificados] = useState(false);
  const [showCalendario, setShowCalendario] = useState(false);
  const [showNovoProjeto, setShowNovoProjeto] = useState(false);

  // Dados derivados do contexto de autenticação
  const userData = {
    nome: auth.user?.nome || '',
    email: auth.user?.email || '',
    horasVoluntarias: 0,
    inscricoes: [] as number[]
  };

  const orgData = {
    nome: auth.user?.nome || '',
    email: auth.user?.email || '',
    oportunidades: [] as number[]
  };

  const [currentPage, setCurrentPage] = useState<'home' | 'oportunidades' | 'detalhes' | 'painel' | 'painel-org'>('home');

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [currentPage]);

  // Redirecionar para painel após login
  useEffect(() => {
    if (auth.isLoggedIn && currentPage === 'home' && !showLogin) {
      // Não redirecionar automaticamente ao carregar — apenas após login explícito
    }
  }, [auth.isLoggedIn]);

  const [selectedOportunidade, setSelectedOportunidade] = useState<number | null>(null);
  const [inscricaoData, setInscricaoData] = useState({
    motivacao: '',
    disponibilidade: '',
    experiencia: ''
  });
  const [loginData, setLoginData] = useState({
    email: '',
    senha: ''
  });
  const [loginError, setLoginError] = useState('');
  const [loginLoading, setLoginLoading] = useState(false);

  const [novoProjeto, setNovoProjeto] = useState({
    titulo: '',
    categoria: '',
    descricao: '',
    cidade: '',
    estado: '',
    horario: '',
    vagasTotal: '',
    requisitos: '',
    beneficios: '',
    contato: '',
    fotos: [] as string[]
  });
  const [formData, setFormData] = useState({
    nomeCompleto: '',
    cpf: '',
    email: '',
    senha: '',
    confirmarSenha: '',
    ocupacao: '',
    afinidades: [] as string[],
    raca: '',
    genero: '',
    aceitaTermos: false
  });
  const [cadastroError, setCadastroError] = useState('');
  const [cadastroLoading, setCadastroLoading] = useState(false);

  // ===== HANDLERS =====

  const handleSubmitCadastro = async (e: React.FormEvent) => {
    e.preventDefault();
    setCadastroError('');

    if (formData.senha !== formData.confirmarSenha) {
      setCadastroError('As senhas não coincidem.');
      return;
    }

    setCadastroLoading(true);
    try {
      await cadastrarVoluntario({
        nome: formData.nomeCompleto,
        cpf: formData.cpf,
        email: formData.email,
        senha: formData.senha,
        genero: formData.genero || undefined,
        etnia: formData.raca || undefined,
        formacoes: formData.ocupacao ? [{
          nome: formData.ocupacao,
          tipo: 'Ocupacao'
        }] : undefined,
        areasAfinidadeIds: formData.afinidades
      });

      alert('Cadastro realizado com sucesso! Faça login para acessar sua conta.');
      setShowCadastro(false);
      setShowLogin(true);
      setFormData({
        nomeCompleto: '',
        cpf: '',
        email: '',
        senha: '',
        confirmarSenha: '',
        ocupacao: '',
        afinidades: [],
        raca: '',
        genero: '',
        aceitaTermos: false
      });
    } catch (err) {
      if (err instanceof ApiException) {
        setCadastroError(err.message);
      } else {
        setCadastroError('Erro ao realizar cadastro. Tente novamente.');
      }
    } finally {
      setCadastroLoading(false);
    }
  };

  const toggleAfinidade = (afinidadeId: number) => {
    setFormData(prev => ({
      ...prev,
      afinidades: prev.afinidades.includes(afinidadeId)
        ? prev.afinidades.filter(a => a !== afinidadeId)
        : [...prev.afinidades, afinidadeId]
    }));
  };

  const handleInscricao = (e: React.FormEvent) => {
    e.preventDefault();
    const opp = opportunities.find(o => o.id === selectedOportunidade);
    console.log('Inscrição enviada:', { oportunidade: opp?.title, ...inscricaoData });
    alert('Inscrição enviada com sucesso! Entraremos em contato em breve.');
    setInscricaoData({ motivacao: '', disponibilidade: '', experiencia: '' });
    setCurrentPage('home');
    setSelectedOportunidade(null);
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    setLoginLoading(true);

    try {
      await auth.login(loginData.email, loginData.senha);
      setShowLogin(false);
      setLoginData({ email: '', senha: '' });
      setCurrentPage('painel');
    } catch (err) {
      if (err instanceof ApiException) {
        setLoginError(err.message);
      } else {
        setLoginError('Erro ao conectar com o servidor. Verifique se a API está rodando.');
      }
    } finally {
      setLoginLoading(false);
    }
  };

  const handleLogout = () => {
    auth.logout();
    setCurrentPage('home');
  };

  const handleCriarProjeto = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Novo projeto:', novoProjeto);
    alert(`Projeto cadastrado com sucesso! (mock)\nFotos anexadas: ${novoProjeto.fotos.length}\nEm breve você receberá um email de confirmação.`);
    setShowNovoProjeto(false);
    setNovoProjeto({
      titulo: '',
      categoria: '',
      descricao: '',
      cidade: '',
      estado: '',
      horario: '',
      vagasTotal: '',
      requisitos: '',
      beneficios: '',
      contato: '',
      fotos: []
    });
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      const newImages: string[] = [];
      Array.from(files).forEach(file => {
        const reader = new FileReader();
        reader.onloadend = () => {
          newImages.push(reader.result as string);
          if (newImages.length === files.length) {
            setNovoProjeto(prev => ({
              ...prev,
              fotos: [...prev.fotos, ...newImages]
            }));
          }
        };
        reader.readAsDataURL(file);
      });
    }
  };

  const removeImage = (index: number) => {
    setNovoProjeto(prev => ({
      ...prev,
      fotos: prev.fotos.filter((_, i) => i !== index)
    }));
  };

  const openOportunidade = (id: number) => {
    setSelectedOportunidade(id);
    setCurrentPage('detalhes');
    window.scrollTo(0, 0);
  };

  return (
    <div className="min-h-screen bg-white">
      <Header
        currentPage={currentPage}
        setCurrentPage={setCurrentPage}
        isLoggedIn={auth.isLoggedIn}
        isOrganizacao={auth.isOrganizacao}
        userData={userData}
        orgData={orgData}
        setShowLogin={setShowLogin}
        setShowCadastro={setShowCadastro}
        handleLogout={handleLogout}
        menuOpen={menuOpen}
        setMenuOpen={setMenuOpen}
      />

      {currentPage === 'home' && (
        <HomePage
          setShowCadastro={setShowCadastro}
          selectedCategory={selectedCategory}
          setSelectedCategory={setSelectedCategory}
          openOportunidade={openOportunidade}
          setCurrentPage={setCurrentPage}
        />
      )}

      {currentPage === 'home' && (
        <Footer
          setIsOrganizacao={() => {}}
          setIsLoggedIn={() => {}}
          setOrgData={() => {}}
          setCurrentPage={setCurrentPage}
          setShowNovoProjeto={setShowNovoProjeto}
        />
      )}

      {currentPage === 'oportunidades' && (
        <OportunidadesPage
          selectedCategory={selectedCategory}
          setSelectedCategory={setSelectedCategory}
          openOportunidade={openOportunidade}
        />
      )}

      {currentPage === 'painel' && (
        <PainelPage
          userData={userData}
          setCurrentPage={setCurrentPage}
          openOportunidade={openOportunidade}
          setShowCertificados={setShowCertificados}
          setShowCalendario={setShowCalendario}
        />
      )}

      {currentPage === 'painel-org' && (
        <PainelOrgPage
          orgData={orgData}
          setShowNovoProjeto={setShowNovoProjeto}
        />
      )}

      {currentPage === 'detalhes' && selectedOportunidade && (
        <DetalhesPage
          selectedOportunidade={selectedOportunidade}
          setCurrentPage={setCurrentPage}
          setSelectedOportunidade={setSelectedOportunidade}
          handleInscricao={handleInscricao}
          inscricaoData={inscricaoData}
          setInscricaoData={setInscricaoData}
        />
      )}

      <NovoProjetoModal
        showNovoProjeto={showNovoProjeto}
        setShowNovoProjeto={setShowNovoProjeto}
        handleCriarProjeto={handleCriarProjeto}
        novoProjeto={novoProjeto}
        setNovoProjeto={setNovoProjeto}
        handleImageUpload={handleImageUpload}
        removeImage={removeImage}
      />

      <CertificadosModal
        showCertificados={showCertificados}
        setShowCertificados={setShowCertificados}
        userData={userData}
      />

      <CalendarioModal
        showCalendario={showCalendario}
        setShowCalendario={setShowCalendario}
      />

      <AccessibilityWidget />

      <LoginModal
        showLogin={showLogin}
        setShowLogin={setShowLogin}
        setShowCadastro={setShowCadastro}
        handleLogin={handleLogin}
        loginData={loginData}
        setLoginData={setLoginData}
        loginError={loginError}
        loginLoading={loginLoading}
      />

      <CadastroModal
        showCadastro={showCadastro}
        setShowCadastro={setShowCadastro}
        setShowLogin={setShowLogin}
        handleSubmitCadastro={handleSubmitCadastro}
        formData={formData}
        setFormData={setFormData}
        toggleAfinidade={toggleAfinidade}
        cadastroError={cadastroError}
        cadastroLoading={cadastroLoading}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
